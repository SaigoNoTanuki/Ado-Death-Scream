# Ado_Death_Scream

A simple mod that adds Ado's screaming after death.

Mod by: SaigoNoTanuki
